﻿// the.quiet.string@gmail.com


#include "ZodiacAIPawnSubsystem.h"

#include "AIController.h"
#include "BrainComponent.h"
#include "Character/ZodiacMonster.h"
#include "ZodiacAIPawnSpawner.h"
#include "ZodiacLogChannels.h"

#include UE_INLINE_GENERATED_CPP_BY_NAME(ZodiacAIPawnSubsystem)

static TAutoConsoleVariable<int32> CVarMaxGlobalAIPawns(
	TEXT("Zodiac.ai.MaxGlobalAIPawns"),
	40,
	TEXT("Maximum global AI pawns at once."),
	ECVF_Default
);

void UZodiacAIPawnSubsystem::Initialize(FSubsystemCollectionBase& Collection)
{
	Super::Initialize(Collection);
}

void UZodiacAIPawnSubsystem::RegisterSpawner(AZodiacAIPawnSpawner* Spawner)
{
	if (!Spawner)
	{
		return;
	}

	RegisteredSpawners.AddUnique(Spawner);
}

void UZodiacAIPawnSubsystem::UnregisterSpawner(AZodiacAIPawnSpawner* Spawner)
{
	if (!Spawner)
	{
		return;
	}
	
	RegisteredSpawners.RemoveAll([Spawner](const TWeakObjectPtr<AZodiacAIPawnSpawner>& WeakPtr)
	{
		return WeakPtr.Get() == Spawner;
	});
}

FZodiacSpawnerPool* UZodiacAIPawnSubsystem::FindSpawnerPool(AZodiacAIPawnSpawner* Spawner)
{
	for (FZodiacSpawnerPool& Entry : SpawnerPools)
	{
		if (Entry.Spawner.Get() == Spawner)
		{
			return &Entry;
		}
	}
	
	return nullptr;
}

FZodiacSpawnerPool& UZodiacAIPawnSubsystem::FindOrAddSpawnerPool(AZodiacAIPawnSpawner* Spawner)
{
	for (FZodiacSpawnerPool& Entry : SpawnerPools)
	{
		if (Entry.Spawner.Get() == Spawner)
		{
			return Entry;
		}
	}

	FZodiacSpawnerPool NewPool;
	NewPool.Spawner = Spawner;

	int32 Index = SpawnerPools.Add(NewPool);
	return SpawnerPools[Index];
}

FZodiacAIPawnClassPool& UZodiacAIPawnSubsystem::FindOrAddMonsterClassPool(FZodiacSpawnerPool& SpawnerPool, const TSubclassOf<AZodiacMonster>& MonsterClass)
{
	for (FZodiacAIPawnClassPool& ACP : SpawnerPool.ClassPools)
	{
		if (ACP.MonsterClass == MonsterClass)
		{
			return ACP;
		}
	}

	FZodiacAIPawnClassPool NewACP;
	NewACP.MonsterClass = MonsterClass;

	int32 NewIndex = SpawnerPool.ClassPools.Add(NewACP);
	return SpawnerPool.ClassPools[NewIndex];
}

void UZodiacAIPawnSubsystem::AddMonsterToPool(AZodiacAIPawnSpawner* Spawner, const TSubclassOf<AZodiacMonster>& ClassToSpawn, const FZodiacZombieSpawnConfig& SpawnConfig)
{
	UWorld* World = GetWorld();
	if (!World || !ClassToSpawn)
	{
		return;
	}

	FActorSpawnParameters SpawnParams;
	SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

	AZodiacMonster* Spawned = World->SpawnActor<AZodiacMonster>(ClassToSpawn, FVector::ZeroVector, FRotator::ZeroRotator, SpawnParams);
	if (!Spawned)
	{
		return;
	}
	
	Spawned->SpawnDefaultController();
	Spawned->Multicast_Sleep();
	
	Spawned->SetSpawnConfig(SpawnConfig);

	// 1) Find or create the pool for that spawner
	FZodiacSpawnerPool& SpawnerPool = FindOrAddSpawnerPool(Spawner);

	// 2) Find or create the sub-pool for that monster class
	auto& [MonsterClass, Instances] = FindOrAddMonsterClassPool(SpawnerPool, ClassToSpawn);

	// 3) Actually store the monster
	Instances.Add(Spawned);
}

void UZodiacAIPawnSubsystem::SendMonsterBackToPool(AZodiacAIPawnSpawner* Spawner, AZodiacMonster* Monster)
{
	if (!Monster || !Spawner)
	{
		return;
	}

	// 1) Determine the monster’s class
	TSubclassOf<AZodiacMonster> MonsterClass = Monster->GetClass();

	// 2) Find (or create) the spawner’s pool
	FZodiacSpawnerPool& SpawnerPool = FindOrAddSpawnerPool(Spawner);

	// 3) Find (or create) the array of monsters for that class
	FZodiacAIPawnClassPool& ClassPool = FindOrAddMonsterClassPool(SpawnerPool, MonsterClass);

	// 4) Actually store the monster in the pool
	ClassPool.Instances.AddUnique(Monster);
	
	ActiveMonsters.Remove(Monster);

	// See if we can spawn something from the queue
	ProcessSpawnRequests();
}

void UZodiacAIPawnSubsystem::HatchAllPawnsFromPool()
{
	for (auto& SpawnerPool : SpawnerPools)
	{
		if (AZodiacAIPawnSpawner* Spawner = SpawnerPool.Spawner.Get())
		{
			Spawner->SpawnAllMonstersFromPool();
		}
	}
}

void UZodiacAIPawnSubsystem::SendAllPawnsBackToPool()
{
	
	for (auto& SpawnerPool : SpawnerPools)
	{
		if (AZodiacAIPawnSpawner* Spawner = SpawnerPool.Spawner.Get())
		{
			Spawner->SendAllMonstersBackToPool();
		}
	}
}

AZodiacMonster* UZodiacAIPawnSubsystem::HatchMonsterFromPool(AZodiacAIPawnSpawner* Spawner, const TSubclassOf<AZodiacMonster>& RequestedClass)
{
	if (!Spawner || !RequestedClass)
	{
		return nullptr;
	}

	// 1) Find the existing spawner pool
	FZodiacSpawnerPool* SpawnerPoolPtr = FindSpawnerPool(Spawner);
	if (!SpawnerPoolPtr)
	{
		return nullptr;
	}

	// 2) Find the monster class pool
	FZodiacAIPawnClassPool* ClassPoolPtr = nullptr;
	for (FZodiacAIPawnClassPool& ClassPool : SpawnerPoolPtr->ClassPools)
	{
		if (ClassPool.MonsterClass == RequestedClass)
		{
			ClassPoolPtr = &ClassPool;
			break;
		}
	}
	if (!ClassPoolPtr || ClassPoolPtr->Instances.Num() == 0)
	{
		return nullptr;
	}
	
	// 3) Pop from the array
	AZodiacMonster* Monster = ClassPoolPtr->Instances.Pop(EAllowShrinking::No);
	if (Monster)
	{
		ActiveMonsters.Add(Monster);
	}

	return Monster;
}

void UZodiacAIPawnSubsystem::QueueSpawnRequest(AZodiacAIPawnSpawner* Spawner, const TMap<TSubclassOf<AZodiacMonster>, uint8>& RequestedMap)
{
	if (!Spawner)
	{
		return;
	}

	FSpawnRequest NewRequest(Spawner, RequestedMap);
	SpawnRequestsQueue.Add(NewRequest);
	ProcessSpawnRequests();

	UE_LOG(LogZodiacSpawner, Log, TEXT("Spawn request added from %s."), *Spawner->GetActorNameOrLabel());
}

void UZodiacAIPawnSubsystem::ProcessSpawnRequests()
{
	// We'll keep popping from the front of the array (like a queue)
	// while there's enough capacity. 
	
	int32 i = 0;
	while (i < SpawnRequestsQueue.Num())
	{
		const FSpawnRequest& Request = SpawnRequestsQueue[i];
		AZodiacAIPawnSpawner* Spawner = Request.Spawner.Get();
		if (!Spawner)
		{
			SpawnRequestsQueue.RemoveAt(i);
			continue;
		}

		int32 CurrentLimit = CVarMaxGlobalAIPawns.GetValueOnGameThread();
		int32 CurrentlyActive = GetNumberOfActivePawns();
		int32 CurrentlySpawning = 0;
		for (auto& [K, V] : CachedNumberOfSpawning)
		{
			CurrentlySpawning += V;
		}
		
		int32 CapacityLeft = CurrentLimit - CurrentlyActive - CurrentlySpawning;
		
		int32 RequiredSpawnCount = 0;
		for (auto& Pair : Request.MonsterToSpawnMap)
		{
			RequiredSpawnCount += Pair.Value;
		}
		
		if (RequiredSpawnCount <= CapacityLeft)
		{
			// We have enough capacity for the spawn request. 
			Spawner->PerformQueuedSpawn(Request.MonsterToSpawnMap);
			CachedNumberOfSpawning.Add(Spawner, RequiredSpawnCount);
			
			// Remove the request from the queue
			SpawnRequestsQueue.RemoveAt(i);
			
			UE_LOG(LogZodiacSpawner, Log, TEXT("Perform queued spawn request. Requested: %d, Capacity left: %d, Active + Spawning: %d"), RequiredSpawnCount, CapacityLeft, CurrentlyActive + CurrentlySpawning);
		}
		else
		{
			break; 
		}
	}
}

int32 UZodiacAIPawnSubsystem::GetNumberOfActivePawns() const
{
	return ActiveMonsters.Num();
}

int32 UZodiacAIPawnSubsystem::GetCurrentSpawnLimit() const
{
	return CVarMaxGlobalAIPawns.GetValueOnGameThread();
}

void UZodiacAIPawnSubsystem::NotifySpawnFinished(AZodiacAIPawnSpawner* Spawner)
{
	CachedNumberOfSpawning.Remove(Spawner);
}

void UZodiacAIPawnSubsystem::PauseAllMonsters()
{
	for (auto& Spawner : RegisteredSpawners)
	{
		if (Spawner.IsValid())
		{
			for (auto& Monster : Spawner->SpawnedMonsters)
			{
				if (Monster)
				{
					if (AAIController* AC = Cast<AAIController>(Monster->GetController()))
					{
						FString Reason = TEXT("Paused by ZodiacAIPawnSubsystem");
						AC->BrainComponent->PauseLogic(Reason);
					}
				}
			}
		}
	}
}

void UZodiacAIPawnSubsystem::ResumeAllMonsters()
{
	for (auto& Spawner : RegisteredSpawners)
	{
		if (Spawner.IsValid())
		{
			for (auto& Monster : Spawner->SpawnedMonsters)
			{
				if (Monster)
				{
					if (AAIController* AC = Cast<AAIController>(Monster->GetController()))
					{
						FString Reason = TEXT("Resumed by ZodiacAIPawnSubsystem");
						AC->BrainComponent->ResumeLogic(Reason);
					}
				}
			}
		}
	}
}

void UZodiacAIPawnSubsystem::SpawnDebugPawns()
{
	for (auto& Spawner : RegisteredSpawners)
	{
		if (Spawner.IsValid())
		{
			if (Spawner->ActorHasTag(FName("Debug")))
			{
				// Spawn only when it's not spawned yet.
				if (Spawner->SpawnedMonsters.Num() != Spawner->TotalNumberOfInitialSpawn)
				{
					Spawner->SpawnAllMonstersFromPool();	
				}
				else
				{
					UE_LOG(LogZodiacSpawner, Display, TEXT("Debug pawns already spawned"));
				}
			}
		}
	}
}

void UZodiacAIPawnSubsystem::KillDebugPawns()
{
	for (auto& Spawner : RegisteredSpawners)
	{
		if (Spawner.IsValid())
		{
			if (Spawner->ActorHasTag(FName("Debug")))
			{
				Spawner->SendAllMonstersBackToPool();
			}
		}
	}
}