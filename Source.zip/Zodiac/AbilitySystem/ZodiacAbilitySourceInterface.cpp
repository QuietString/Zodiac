﻿// Copyright Epic Games, Inc. All Rights Reserved.

#include "ZodiacAbilitySourceInterface.h"

#include UE_INLINE_GENERATED_CPP_BY_NAME(ZodiacAbilitySourceInterface)

UZodiacAbilitySourceInterface::UZodiacAbilitySourceInterface(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{}

