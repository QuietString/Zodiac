﻿// the.quiet.string@gmail.com


#include "ZodiacHeroActor.h"

#include UE_INLINE_GENERATED_CPP_BY_NAME(ZodiacHeroActor)

AZodiacHeroActor::AZodiacHeroActor(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	
}
