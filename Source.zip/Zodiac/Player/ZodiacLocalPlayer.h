// the.quiet.string@gmail.com

#pragma once

#include "CoreMinimal.h"
#include "CommonLocalPlayer.h"
#include "ZodiacLocalPlayer.generated.h"

/**
 * 
 */
UCLASS()
class ZODIAC_API UZodiacLocalPlayer : public UCommonLocalPlayer
{
	GENERATED_BODY()
	
};
