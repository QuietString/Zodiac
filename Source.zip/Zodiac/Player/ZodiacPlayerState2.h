﻿// the.quiet.string@gmail.com

#pragma once

#include "CoreMinimal.h"
#include "ModularPlayerState.h"
#include "ZodiacPlayerState2.generated.h"

/**
 * 
 */
UCLASS()
class ZODIAC_API AZodiacPlayerState2 : public AModularPlayerState
{
	GENERATED_BODY()
};
