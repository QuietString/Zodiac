﻿// the.quiet.string@gmail.com

#pragma once

#include "CommonUserWidget.h"


#include "ZodiacWeaponUserInterface.generated.h"


UCLASS()
class UZodiacWeaponUserInterface : public UCommonUserWidget
{
	GENERATED_BODY()

public:
	

protected:

};
