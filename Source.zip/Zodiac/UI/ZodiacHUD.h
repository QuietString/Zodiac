﻿// the.quiet.string@gmail.com

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/HUD.h"
#include "ZodiacHUD.generated.h"

/**
 * 
 */
UCLASS()
class ZODIAC_API AZodiacHUD : public AHUD
{
	GENERATED_BODY()
};
