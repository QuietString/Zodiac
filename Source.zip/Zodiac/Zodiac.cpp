// the.quiet.string@gmail.com

#include "Zodiac.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, Zodiac, "Zodiac" );
 